#!/bin/bash

# IR Thermal Imaging Cameras for Drones, FPV & RC - Cerritos v003b
#
# read_sbus install script for Raspbian 64 bit
#
# (c) catch22mania 11/2024 https://www.youtube.com/@catch22mania


# experimental Python library read_sbus (this is just a quick and dirty hack for testing)

# the rx_read-002b.sh script installs the Python library read_sbus which reads the output of an SBUS receiver

# and an experimental test script that reacts on the output of two channels in order to control the ptc script

# - channel5 (three position switch) - e.g. (next) colour map, centre spot (on, off), hot spot (on, off) <- ptc script - see ~/starter.sh.ptc.examples

# - channel6 (momentary switch) - trigger for the current channel5 position

# read_sbus is a Python script and not fast enough for reliable values, but it could be modified to work a bit more reliable. 

# how to connect the receiver? TBS Nano RX output 1 and 2 via CRSF to the flight controller, output 4 via SBUS to GPIO 4 pin (+1k Ohm resistor) 


oldpath=`pwd`

# update Raspbian

sudo apt-get update
sudo apt-get -y upgrade

# install stuff

# python -m pip install bitarray

sudo apt-get install -y xdotool pigpiod pigpio python3-bitarray #cam test, io stuff serial fc connection)

# pigpiod stuff

# sudo systemctl start pigpiod # start pigpiod daemon
# sudo systemctl enable pigpiod # start at boot time

# testing!

mkdir ~/testing
cp testing/read_sbus-patch-c22-014.ptc.diff ~/testing
cp testing/read_sbus-patch-c22-014.seek.diff ~/testing
cd ~/testing

wget https://github.com/VermontCoder/read_sbus/archive/refs/heads/main.zip
unzip main.zip
rm main.zip
mv read_sbus-main read_sbus_main

cp read_sbus_main/read_sbus_from_GPIO_template.py .
cp read_sbus_from_GPIO_template.py read_sbus_from_GPIO_template.py.orig 

# ptc patch

patch read_sbus_from_GPIO_template.py < read_sbus-patch-c22-014.ptc.diff 
mv read_sbus_from_GPIO_template.py read_sbus-patched-c22-014.ptc.py

# seek patch

cp read_sbus_from_GPIO_template.py.orig read_sbus_from_GPIO_template.py 
patch read_sbus_from_GPIO_template.py < read_sbus-patch-c22-014.seek.diff
mv read_sbus_from_GPIO_template.py read_sbus-patched-c22-014.seek.py

# pigpiod stuff

# sudo systemctl start pigpiod # start pigpiod daemon
# sudo systemctl enable pigpiod # start at boot time

# (ptc) simple experimental serial Raspi <- SBUS receiver connection (read_sbus)

#echo >> ~/starter.sh
#echo '# ptc - simple experimental serial Raspi <- SBUS connection (read_sbus)' >> ~/starter.sh
#echo >> ~/starter.sh
#echo "# cd /home/`whoami`/testing" >> ~/starter.sh
#echo '# python read_sbus-patched-c22-012.ptc.py' >> ~/starter.sh
#echo >> ~/starter.sh

# (seek) simple experimental serial Raspi <- SBUS receiver connection (read_sbus)

#echo >> ~/starter.sh
#echo '# seek - simple experimental serial Raspi <- SBUS connection (read_sbus)' >> ~/starter.sh
#echo >> ~/starter.sh
#echo "# cd /home/`whoami`/testing" >> ~/starter.sh
#echo '# python read_sbus-patched-c22-012.seek.py' >> ~/starter.sh
#echo >> ~/starter.sh

echo
echo "read_sbus stuff -> ~/testing"

exit 0;


