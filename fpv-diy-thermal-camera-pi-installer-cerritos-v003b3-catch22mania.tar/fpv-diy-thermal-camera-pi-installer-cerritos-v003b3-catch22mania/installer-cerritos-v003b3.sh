#!/bin/bash

# IR Thermal Imaging Cameras for Drones, FPV & RC - Cerritos v003b3
#
# libseek-thermal, v4l2, UVC, Infiray, Seek, mlx90460, Flir (untested), ... install script for Raspbian 64 bit
#
# (c) catch22mania 04/2025 https://www.youtube.com/@catch22mania


# add Seek artifacts patch via command line to reduce Seek Compact artifacts (blurry corners)
#
# run installer with an argument: bash installer-cerritos-v003b2.sh patch2

seek_artifacts_patch=false;

if [ "$1" = "patch2" ]; then
    seek_artifacts_patch=true;
    echo "additional Seek artifacts patch = true"
fi

# check Raspbian version

if ! grep -q -wi "Debian GNU/Linux 11" /etc/issue; then
    echo;echo "This Raspbian version isn't support. Please install Raspbian BULLSEYE 64 bit"
    echo;echo "Download: https://www.raspberrypi.com/software/operating-systems"
    echo;echo "Scroll down to BULLSEYE 64 bit and download Raspberry Pi OS (Legacy) with desktop";echo
    exit 0;
fi

# check RAM size

ram_size=$(cat /proc/meminfo | grep -i 'memtotal' | grep -o '[[:digit:]]*')
swap_size=$(cat /proc/meminfo | grep -i 'SwapTotal' | grep -o '[[:digit:]]*')
total_memory=`expr $ram_size + $swap_size`

echo "ram_size: $ram_size"; echo "swap_size: $swap_size"; echo "total_memory: $total_memory"

compile_seek=true;

if [ $total_memory -lt 3900000 ]; then
    echo; echo "Your Pi needs 4 GB swap memory in order to compile the Seek driver - /etc/dphys-swapfile: CONF_SWAPSIZE=4096 and CONF_MAXSWAP=4096"; echo
    echo "here's a quick and simple tutorial: https://diyusthad.com/2022/01/how-to-increase-swap-size-in-raspberry-pi.html "; echo
  
    read -p "Do you want to proceed without compiling the Seek driver, abort or ignore warning? (y/a/i) " yai
    case $yai in 
        y ) echo; compile_seek=false; echo "Seek driver disabled, continue ...";;
        i ) echo; echo "ignore warning, continue ..."; compile_seek=true;;
        a ) echo; echo installer exit;
        exit 1;;
        * ) echo; echo installer exit;
            exit 1;;
    esac   
fi

# continue

oldpath=`pwd`

# update Raspbian

sudo apt-get update
sudo apt-get -y upgrade

# install Seek (libseek-thermal) & InfiRay (v4l2) stuff 

sudo apt-get install -y cmake libopencv-dev libusb-1.0-0-dev unclutter v4l-utils mplayer v4l2loopback-utils webcamoid raspberrypi-kernel-headers # (optional, color maps)

cd ~
wget https://github.com/OpenThermal/libseek-thermal/archive/refs/heads/master.zip
unzip master.zip

if $compile_seek; then
    echo compiling Seek driver; echo

    cp $oldpath/testing/seek-c22-003b.diff . # seek_viewer patch
    patch -p0 < seek-c22-003b.diff

    if $seek_artifacts_patch; then
        echo "seek_artifacts_patch"
        cp $oldpath/testing/seek-c22-003b-anti-artifacts.diff . # seek artifacts patch
        patch -p0 < seek-c22-003b-anti-artifacts.diff
    fi
    
    rm seek-c22-003b.diff seek-c22-003b-anti-artifacts.diff
    cd ~/libseek-thermal-master
    mkdir build
fi

echo 'SUBSYSTEM=="usb", ATTRS{idVendor}=="289d", ATTRS{idProduct}=="0010", MODE="0666", GROUP="users"' | sudo tee -a /etc/udev/rules.d/46-seek.rules
echo 'SUBSYSTEM=="usb", ATTRS{idVendor}=="289d", ATTRS{idProduct}=="0011", MODE="0666", GROUP="users"' | sudo tee -a /etc/udev/rules.d/46-seek.rules

sudo udevadm control --reload

rm ~/master.zip

# v4l2loopback for streaming # sudo modprobe v4l2loopback devices=1 # v4l2-ctl --list-devices

mkdir ~/testing; cd ~/testing
curl -LO https://github.com/umlaeute/v4l2loopback/archive/refs/tags/v0.12.5.tar.gz
tar xzf v0.12.5.tar.gz && cd v4l2loopback-0.12.5
make && sudo make install
sudo depmod -a

# Seek libseek-thermal examples

#echo >> ~/starter.sh.seek.examples 
#echo '# Seek Compact & Compact Pro examples - catch22mania' >> ~/starter.sh.seek.examples
#echo >> ~/starter.sh.seek.examples
#echo '# CVBS, composite out (PAL; 576i)' >> ~/starter.sh.seek.examples 
#echo >> ~/starter.sh.seek.examples 
#echo '# https://github.com/OpenThermal/libseek-thermal' >> ~/starter.sh.seek.examples
#echo >> ~/starter.sh.seek.examples
#echo >> ~/starter.sh.seek.examples
#echo "# cd /home/`whoami`/libseek-thermal-master/build/examples" >> ~/starter.sh.seek.examples
#echo >> ~/starter.sh.seek.examples
#echo '# ./seek_viewer_c22 -r 90 -t seek' >> ~/starter.sh.seek.examples
#echo >> ~/starter.sh.seek.examples
#echo '# ./seek_viewer_c22 -r 180 -t seek -F flat_field.png' >> ~/starter.sh.seek.examples
#echo  >> ~/starter.sh.seek.examples
#echo '# ./seek_viewer_c22 -r 180 -s 3.5 -t seek -c 18 -F flat_field.png' >> ~/starter.sh.seek.examples
#echo  >> ~/starter.sh.seek.examples
#echo '# ./seek_viewer_c22 -r 270  -t seekpro -s 1.4 -c 18' >> ~/starter.sh.seek.examples
#echo >> ~/starter.sh.seek.examples
#echo '# ./seek_viewer_c22 -t seekpro -c 18 -F flat_field-pro.png' >> ~/starter.sh.seek.examples
#echo >> ~/starter.sh.seek.examples
#echo '# ./seek_viewer_c22 -r 180 -s 2.2 -t seekpro -c 18 -F flat_field-pro.png' >> ~/starter.sh.seek.examples
#echo >> ~/starter.sh.seek.examples
#echo '# create flat field image:' >> ~/starter.sh.seek.examples
#echo  >> ~/starter.sh.seek.examples
#echo "cd /home/`whoami`/libseek-thermal-master/build/examples" >> ~/starter.sh.seek.examples
#echo >> ~/starter.sh.seek.examples
#echo '# ./seek_create_flat_field -t seekpro' >> ~/starter.sh.seek.examples
#echo  >> ~/starter.sh.seek.examples
#echo '# ./seek_create_flat_field -t seek' >> ~/starter.sh.seek.examples
#echo  >> ~/starter.sh.seek.examples

# InfiRay v4l2 examples

#echo >> ~/starter.sh.infiray.examples 
#echo '# InfiRay P2 Pro examples - catch22mania' >> ~/starter.sh.infiray.examples
#echo >> ~/starter.sh.infiray.examples
#echo '# CVBS, composite out (PAL; 576i)' >> ~/starter.sh.infiray.examples
#echo >> ~/starter.sh.infiray.examples 
#echo '# mplayer tv:// -tv driver=v4l2:device=/dev/video0' >> ~/starter.sh.infiray.examples 
#echo >> ~/starter.sh.infiray.examples 
#echo '# mplayer tv:// -tv driver=v4l2:device=/dev/video0:width=256:height=384' >> ~/starter.sh.infiray.examples
#echo >> ~/starter.sh.infiray.examples 
#echo '# mplayer tv:// -tv driver=v4l2:device=/dev/video0:width=256:height=192:fps=25:outfmt=mjpeg' >> ~/starter.sh.infiray.examples 
#echo >> ~/starter.sh.infiray.examples 
#echo '# mplayer tv:// -tv driver=v4l2:device=/dev/video0:width=256:height=192:fps=25:outfmt=mjpeg -fs' >> ~/starter.sh.infiray.examples 
#echo >> ~/starter.sh.infiray.examples 

#chmod 700 ~/starter.sh.seek.examples

# starter.sh (executed at desktop start up) 

#echo '#!/bin/bash' >> ~/starter.sh
#echo  >> ~/starter.sh
#echo '#' >> ~/starter.sh
#echo '# Seek, Infiray, MLX, etc. autostart script' >> ~/starter.sh
#echo '#' >> ~/starter.sh
#echo '# catch22mania - https://www.youtube.com/@catch22mania' >> ~/starter.sh
#echo '#' >> ~/starter.sh
#echo >> ~/starter.sh
#echo >> ~/starter.sh
#echo '# Seek Compact' >> ~/starter.sh
#echo >> ~/starter.sh
#echo "# cd /home/`whoami`/libseek-thermal-master/build/examples" >> ~/starter.sh
#echo '# ./seek_viewer_c22 -r 180 -s 3.5 -t seek -c 18; sleep 1; ./seek_viewer_c22 -r 180 -s 3.5 -t seek -c 18;' >> ~/starter.sh
#echo '# ./seek_viewer_c22 -r 180 -s 3.5 -t seek -c 18 -F flat_field.png' >> ~/starter.sh
#echo >> ~/starter.sh
#echo >> ~/starter.sh
#echo '# Seek Compact Pro' >> ~/starter.sh
#echo >> ~/starter.sh
#echo "# cd /home/`whoami`/libseek-thermal-master/build/examples" >> ~/starter.sh
#echo '# ./seek_viewer_c22 -r 180 -s 2.2 -t seekpro -c 18; sleep 1;./seek_viewer_c22 -r 180 -s 2.2 -t seekpro -c 18' >> ~/starter.sh
#echo '# ./seek_viewer_c22 -r 180 -s 2.2 -t seekpro -c 18 -F flat_field-pro.png' >> ~/starter.sh
#echo >> ~/starter.sh
#echo >> ~/starter.sh
#echo '# InfiRay P2 Pro' >> ~/starter.sh
#echo >> ~/starter.sh
#echo '# mplayer tv:// -tv driver=v4l2:device=/dev/video0:width=256:height=192:fps=25:outfmt=mjpeg -fs' >> ~/starter.sh
#echo >> ~/starter.sh
#echo >> ~/starter.sh
#echo '# MLX90640' >> ~/starter.sh
#echo >> ~/starter.sh
#echo '# python ~/mlx90640/pi_therm_cam-c22-v4-patched.py' >> ~/starter.sh

#chmod 755 ~/starter.sh

# prepare for hide window deco 

# change window manager (mutter to openbox-lxde)

sudo sed -i "s/mutter/openbox-lxde/g" /etc/xdg/lxsession/LXDE-pi/desktop.conf

cp -rf /etc/xdg/openbox/ ~/.config/

# autostart

mkdir -p ~/.config/lxsession/LXDE-pi/
cp /etc/xdg/lxsession/LXDE-pi/* ~/.config/lxsession/LXDE-pi/
echo "/home/`whoami`/starter.sh" >> ~/.config/lxsession/LXDE-pi/autostart

# screensaver

sed -i /xscreensaver/d ~/.config/lxsession/LXDE-pi/autostart
echo 'xset s noblank' >> ~/.config/lxsession/LXDE-pi/autostart
echo 'xset -dpms' >> ~/.config/lxsession/LXDE-pi/autostart
echo 'xset -s off' >> ~/.config/lxsession/LXDE-pi/autostart

## TV out PAL, 4:3 (CVBS, composite out)
#
# /boot/config.txt
#
# enable_tvout=1
# sdtv_mode=2
# sdtv_aspect=1

sudo sed -i "s/#sdtv_mode=2/sdtv_mode=2\nsdtv_aspect=1/g" /boot/config.txt

# splash screen

sudo mv /usr/share/plymouth/themes/pix/splash.png /usr/share/plymouth/themes/pix/splash.png.pi
sudo cp $oldpath/pics/uc-boot-576i-crop.png /usr/share/plymouth/themes/pix/splash.png

# mlx stuff

sudo sed -i "s/#dtparam=i2c_arm=on/dtparam=i2c_arm=on,i2c_arm_baudrate=400000/g" /boot/config.txt

sudo pip3 install pithermalcam # global
#pip3 install pithermalcam # local
mkdir ~/mlx90640
cp /usr/local/lib/python3.9/dist-packages/pithermalcam/pi_therm_cam.py ~/mlx90640/
cp  $oldpath/mlx90640/pi_therm_cam-c22-v4.diff ~/mlx90640
cd ~/mlx90640
cp pi_therm_cam.py pi_therm_cam.py.orig
patch < pi_therm_cam-c22-v4.diff
mv pi_therm_cam.py pi_therm_cam-c22-v4-patched.py

# mlx dev stuff

cd ~/mlx90640
git clone -b master --single-branch https://github.com/tomshaffner/PiThermalCam.git
pip3 install -r PiThermalCam/requirements.txt


# copy examples

mememe=`whoami`
cd $oldpath/temp
chmod 755  *
sed -i "s/homepath/$mememe/g" starter*
cp starter* ~

# copy Cerrito docs  to ~

cd $oldpath
cp -ax docs ~

# engl. only

cd ~
rm -r Bookshelf/ Documents/ Music/ Pictures/ Public/ Templates/ Videos/

# links

#chromium-browser https://www.youtube.com/@catch22mania https://github.com/OpenThermal/libseek-thermal http://www.mplayerhq.hu/design7/documentation.html https://github.com/tomshaffner/PiThermalCam https://habr.com/en/articles/441050/ https://www.rcgroups.com/forums/showthread.php?4321715-FPV-Thermal-Cameras-coming-soon-MLX90640-InfiRay-P2-Pro-Seek-Compact-Pro-FF  >/dev/null 2>/dev/null &

# workaround to fix issues with numpy 2.x & opencv | dev idiots

pip install numpy==1.23
# pip install "numpy>=1,<2" # auto select version bigger 1 and smaller 2
sudo pip install opencv-python==4.10.0.84


# apps & paths

echo 
echo 'Seek Compact & Compact Pro, InfiRay P2 Pro, MLX90640 install script - (c) catch22mania 2024 https://www.youtube.com/@catch22mania'
echo 
echo 'docs -> ~/docs'
echo 
echo 'libseek-thermal binaries -> ~/libseek-thermal-master/build/examples/'
echo
echo 'libseek-thermal dev stuff -> ~/libseek-thermal-master/'
echo
echo 'MLX90640 scripts & dev stuff -> ~/mlx90640'
echo 
echo 'autostart (analog) script -> ~/starter.sh'
echo
echo 'autostart (digital) script -> ~/starter.digital.sh'
echo
echo 'examples InfiRay -> ~/starter.sh.infiray.examples'
echo
echo 'examples Seek -> ~/starter.sh.seek.examples'
echo 
echo 'tools (hide desktop, -window decor) -> ~/install/tools'
echo

exit 0

