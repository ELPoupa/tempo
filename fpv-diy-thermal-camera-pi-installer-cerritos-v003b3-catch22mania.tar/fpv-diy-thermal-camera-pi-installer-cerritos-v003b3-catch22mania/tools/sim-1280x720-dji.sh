#!/bin/bash

# IR Thermal Cameras for Drones, FPV & RC 
#
# libseek-thermal, v4l2, mlx90460 install script for Raspbian 64 bit
#
# (c) catch22mania 03/2025 https://www.youtube.com/@catch22mania

# create a 1280x720 modeline and switch to 1280x720 in order to test apps with the DJI dev board resolution
# (in case Raspbian doesn't create the modeline automatically)

xrandr --newmode "1280x720x" 74.11 1280 1392 1440 1648 720 723 725 750 +Hsync +Vsync
xrandr --addmode HDMI-1 "1280x720x"
xrandr --output HDMI-1 --mode "1280x720x"
