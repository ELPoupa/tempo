the pi5-bookworm folder contains experimental installers for Raspbian Bookworm


- OpenCV, Python and other issues possible

some scripts and apps need to be ajusted in order to work as good as under Raspbian Bullseye


- changing to x11 might improve compatibilty

sudo raspi-config

6 Advanced Options

A6 Wayland

W1 X11 Openbox window manager with X11 backend

ok and reboot


- pigpiod 1.79 doesn't work on Pi5 - needed by read_sbus scripts

inux@raspberrypi:~ $ /usr/bin/pigpiod -l
2024-11-20 18:12:32 gpioHardwareRevision: unknown rev code (c04170)
2024-11-20 18:12:32 initCheckPermitted: 
+---------------------------------------------------------+
|Sorry, this system does not appear to be a raspberry pi. |
|aborting.                                                |
+---------------------------------------------------------+


Can't initialise pigpio library
linux@raspberrypi:~ $ od -x /proc/device-tree/system/linux,revision
0000000 c000 7041
0000004

- MLX stuff is disabled


- 
