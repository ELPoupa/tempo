#!/bin/bash

# IR Thermal Cameras for Drones, FPV & RC 
#
# libseek-thermal, v4l2, mlx90460 install script for Raspbian 64 bit
#
# (c) catch22mania 01/2024 https://www.youtube.com/@catch22mania

# enable window decor (Openbox) - then reboot Pi

# Pi with more than 2 GB?

perl -0777 -i -pe 's/<application class="\*">\n<decor>no<\/decor>\n<\/application>\n//g' ~/.config/openbox/rc.xml

# Pi Zero 2 W

perl -0777 -i -pe 's/<application class="\*">\n<decor>no<\/decor>\n<\/application>\n//g' ~/.config/openbox/lxde-pi-rc.xml

#   <applications>
#		<application class="*">
#		<decor>no</decor>
#  </application>
