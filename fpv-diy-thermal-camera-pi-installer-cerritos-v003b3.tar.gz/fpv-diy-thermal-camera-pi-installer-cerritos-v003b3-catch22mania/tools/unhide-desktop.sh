#!/bin/bash

# IR Thermal Cameras for Drones, FPV & RC 
#
# libseek-thermal, v4l2, mlx90460 install script for Raspbian 64 bit
#
# (c) catch22mania 04/2023 https://www.youtube.com/@catch22mania

# hide panel etc. - start menu still available (icon hidden)

rm ~/.config/pcmanfm/LXDE-pi/desktop-items-0.conf
rm ~/.config/lxpanel/LXDE-pi/panels/panels

