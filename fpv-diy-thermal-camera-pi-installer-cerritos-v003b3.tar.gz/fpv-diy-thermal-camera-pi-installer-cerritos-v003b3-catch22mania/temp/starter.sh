#!/bin/bash

#
# DIY IR Thermal Imaging Cameras for Drones, FPV & RC - Cerritos v003b
#
# UVC cams ,Seek, Infiray, MLX, etc. autostart script
#
# catch22mania - https://www.youtube.com/@catch22mania
#

# autostart script for analog systems - analog VTX - output via CVBS port

#
#
# IMPORTANT: if you uncomment more than one line add a  &  at the end of a command (line(s)). It's only necessary if a command locks
# the shell like seek_viewer, mplayer or ptc script. if you're unsure just add the &
#
# example: ./seek_viewer_c22 -r 180 -s 2.2 -t seekpro -c 18 # comment ...  ---> ./seek_viewer_c22 -r 180 -s 2.2 -t seekpro -c 18 & # comment
#


# InfiRay P2 Pro & other UVC compatible cameras (via mplayer or ptc script) - options see ~/starter.sh.infiray.examples

# mplayer tv:// -tv driver=v4l2:device=/dev/video0:width=256:height=192:fps=25:outfmt=mjpeg -fs


# ptc script - InfiRay, etc. (testing) - options see ~/starter.sh.ptc.examples

# python /home/homepath/testing/ptc-patched-c22-014.py --fullscreen --colormap 20 & # 256x192; options see ~/starter.sh.ptc.examples
# python /home/homepath/testing/ptc-patched-c22-014.py --fullscreen --colormap 20 --width 720 --height 576 # scale to PAL 576i

# ptc script - method without grey bars in windowed mode - looks like fullscreen - use tools: hide-desktop.sh and window-decor-off; or minimize
# the panel -> panel settings (right click on task bar) -> geometry -> width to 0 - the hidden drop down menu is still available in the top
# left corner

# python /home/homepath/testing/ptc-patched-c22-014.py --colormap 20 --contrast 1.1 --blur 4 &
# while [[ $(xdotool search --name ThermalWindow) == "" ]]; do sleep 0.3; done;
# xdotool search --name "ThermalWindow" windowactivate --sync %1 windowmove -- -8 -2 windowactivate $(xdotool getactivewindow)
# sleep 3; xdotool search --name "ThermalWindow" windowactivate --sync %1 windowmove -- -8 -2 windowactivate $(xdotool getactivewindow)


# Seek Compact - options see ~/starter.sh.seek.examples

# cd /home/homepath/libseek-thermal-master/build/examples
# ./seek_viewer_c22 -r 180 -s 3.5 -t seek -c 18
# ./seek_viewer_c22 -r 180 -s 3.5 -t seek -c 18 -i flat_field.png


# Seek Compact Pro - options see ~/starter.sh.seek.examples

# cd /home/homepath/libseek-thermal-master/build/examples
# ./seek_viewer_c22 -r 180 -s 2.2 -t seekpro -c 18
# ./seek_viewer_c22 -r 180 -s 2.2 -t seekpro -c 18 -i flat_field-pro.png 


# Seek - method without grey bars in windowed mode - looks like fullscreen - use tools: hide-desktop.sh and window-decor-off

# centered
#cd /home/homepath/libseek-thermal-master/build/examples
#./seek_viewer_c22 -r 180 -s 2.2 -t seekpro -c 18 & #;./seek_viewer_c22 -r 180 -s 2.2 -t seekpro -c 18 &
#sleep 10; xdotool search --name "SeekThermal" windowactivate %2; sleep 0.1; xdotool getactivewindow windowmove -- 15 23

# zoom in
#cd /home/homepath/libseek-thermal-master/build/examples
#./seek_viewer_c22 -r 180 -s 2.4 -t seekpro -c 18 & #;./seek_viewer_c22 -r 180 -s 2.2 -t seekpro -c 18 &
#sleep 10; xdotool search --name "SeekThermal" windowactivate %2; sleep 0.1; xdotool getactivewindow windowmove -- -20 0


# Seek - create flat field image

# cd /home/homepath/libseek-thermal-master/build/examples
# ./seek_create_flat_field -t seekpro
# ./seek_viewer_c22 -t seek -i flat_field.png


# Seek - enable streaming - uncomment next command

# sudo modprobe v4l2loopback video_nr=30,32,33 # check created devices: ls -1 /sys/devices/virtual/video4linux

# ./seek_viewer_c22 -t seekpro -w /dev/video30 # example stream via /dev/video30


# streaming example - streaming from /dev/video (Seek app, InfiRay P2 Pro (v4l2), ...)

# drone streaming via Pi with mobile device (dongle or cell phone) - drone <-> Internet <-> client (PC, mobile, GCS, ...)

# Infiray (v4l2, UVC device) - sending a stream to the IP of a client via UDP (transmission speed about 40 KB/s with default resolution)
# ffmpeg  -re -thread_queue_size 64 -f v4l2 -i /dev/video0 -filter:v "crop=w=256:h=192:x=0:y=0" -r 10 -f mpegts udp://CLIENT_IP_ADDRESS:1234?pkt_size=1316

# Seek app - sending a stream to the IP of a client via UDP (transmission speed about 40 KB/s with default resolution)
# ffmpeg -re -thread_queue_size 64 -f v4l2 -i /dev/video30 -r 10 -f mpegts udp://CLIENT_IP_ADDRESS:1234?pkt_size=1316

# receiving stream on the client (CLIENT_IP_ADDRESS = local IP address)
# ffplay -fflags nobuffer -probesize 32 -sync ext -vf setpts=0 udp://CLIENT_IP_ADDRESS:1234


# serial Raspi CRSF daemon; flight controller <-> Raspi <-> mobile device <-> Internet <-> client
# /home/homepath/testing/serial_fc_crsf_daemon -c ~/testing/crsf-config &>/dev/null &

# drone control via serial_fc_crsf client (client <-> Internet <-> drone)
# /home/homepath/testing/serial_fc_crsf_client -i IP_ADDRESS -p PASSWORD -d /dev/RADIO_USB_DEVICE


# ptc - simple experimental serial Raspi <- SBUS connection (read_sbus)

# sudo systemctl start pigpiod; sleep 2
# cd /home/homepath/testing
# python read_sbus-patched-c22-014.ptc.py


# Seek - simple experimental serial Raspi <- SBUS connection (read_sbus)

# sudo systemctl start pigpiod; sleep 2
# cd /home/homepath/testing
# python read_sbus-patched-c22-014.seek.py


# MLX90640

# python ~/mlx90640/pi_therm_cam-c22-v4-patched.py


# start starter.digital.sh

/home/homepath/starter.digital.sh

exit 0;
