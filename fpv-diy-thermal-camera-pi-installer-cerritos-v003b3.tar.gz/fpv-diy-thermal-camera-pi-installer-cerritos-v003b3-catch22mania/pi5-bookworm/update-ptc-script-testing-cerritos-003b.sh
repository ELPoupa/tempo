#!/bin/bash

# IR Thermal Imaging Cameras for Drones, FPV & RC - Cerritos v003b
#
# PTC install script (testing) for Infiray & other compatible USB thermal imaging cameras 
#
# (c) catch22mania 11/2024 https://www.youtube.com/@catch22mania

oldpath=`pwd`

# update Raspbian

sudo apt-get update
sudo apt-get -y upgrade

# install stuff

sudo apt-get install -y webcamoid

# testing!

mkdir ~/testing
cp ../testing/ptc-patch-c22-014.diff ~/testing
cd ~/testing

wget https://github.com/leswright1977/PyThermalCamera/archive/refs/heads/main.zip
unzip main.zip
rm main.zip

cp PyThermalCamera-main/src/tc001v4.2.py .
cp tc001v4.2.py tc001v4.2.py.orig

patch tc001v4.2.py < ptc-patch-c22-014.diff
mv tc001v4.2.py ptc-patched-c22-014.py

# pigpiod stuff - crsf, Mavlink

# sudo systemctl start pigpiod # start pigpiod daemon
# sudo systemctl enable pigpiod # start at boot time

# starter.sh.ptc.examples

#echo >> ~/starter.sh.ptc.examples
#echo '# ptc test script for Infiray P2 Pro & other USB cams' >> ~/starter.sh.ptc.examples
#echo >> ~/starter.sh.ptc.examples
#echo '# a few examples below (python scriptname.py --help)' >> ~/starter.sh.ptc.examples
#echo >> ~/starter.sh.ptc.examples 
#echo >> ~/starter.sh.ptc.examples 
#echo "# python /home/`whoami`/testing/ptc-patched-c22-013.py --fullscreen # start in fullscreen" >> ~/starter.sh.ptc.examples
#echo >> ~/starter.sh.ptc.examples 
#echo "# python /home/`whoami`/testing/ptc-patched-c22-013.py --colormap 4 --fullscreen # start with color map 4 in fullscreen mode" >> ~/starter.sh.ptc.examples
#echo >> ~/starter.sh.ptc.examples 
#echo "# python /home/`whoami`/testing/ptc-patched-c22-013.py --crosshairs # start with crosshairs" >> ~/starter.sh.ptc.examples
#echo >> ~/starter.sh.ptc.examples 
#echo "# python /home/`whoami`/testing/ptc-patched-c22-013.py --blur 2 --contrast 1.2 # start with blur level 2 and contrast 1.2" >> ~/starter.sh.ptc.examples
#echo >> ~/starter.sh.ptc.examples 
#echo 'exit 0'>> ~/starter.sh.ptc.examples 
#echo >> ~/starter.sh.ptc.examples 
#echo >> ~/starter.sh.ptc.examples 
#echo '# Key bindings:' >> ~/starter.sh.ptc.examples
#echo '#' >> ~/starter.sh.ptc.examples
#echo '# c x: cycle through colormaps' >> ~/starter.sh.ptc.examples
#echo '# f w: fullscreen, windowed' >> ~/starter.sh.ptc.examples
#echo '# h : toggle HUD' >> ~/starter.sh.ptc.examples
#echo '# q : quit' >> ~/starter.sh.ptc.examples
#echo '# ' >> ~/starter.sh.ptc.examples
#echo '# 1 : show highest temperature' >> ~/starter.sh.ptc.examples
#echo '# 2 : show centre crosshairs temperature' >> ~/starter.sh.ptc.examples
#echo '# 3 4: change scale - in fullscreen: zoom in/out font' >> ~/starter.sh.ptc.examples
#echo '# 5 6: +/- contrast' >> ~/starter.sh.ptc.examples
#echo '# 7 8: +/- blur' >> ~/starter.sh.ptc.examples
#echo '# ' >> ~/starter.sh.ptc.examples
#echo '# check out the command line options > python ~/testing/ptc-patched-c22-013.py -h' >> ~/starter.sh.ptc.examples
#echo '# ' >> ~/starter.sh.ptc.examples
#echo '# usage: ptc-patched-c22-013.py [-h] [--device DEVICE] [--width WIDTH] [--height HEIGHT] [--fullscreen]' >> ~/starter.sh.ptc.examples
#echo '#                                     [--colormap COLORMAP] [--crosshairs] [--temps] [--blur BLUR] [--contrast CONTRAST]' >> ~/starter.sh.ptc.examples
#echo '# ' >> ~/starter.sh.ptc.examples
#echo '# optional arguments:' >> ~/starter.sh.ptc.examples
#echo '#   -h, --help           show this help message and exit' >> ~/starter.sh.ptc.examples
#echo '#   --device DEVICE      video device number; e.g. 0, use v4l2-ctl --list-devices' >> ~/starter.sh.ptc.examples
#echo '#   --width WIDTH        video output width; e.g. 720, scale to width (scale factor = 1)' >> ~/starter.sh.ptc.examples
#echo '#   --height HEIGHT      video output height; e.g. 576, scale to height (scale factor = 1)' >> ~/starter.sh.ptc.examples
#echo '#   --fullscreen         start in fullscreen; no argument' >> ~/starter.sh.ptc.examples
#echo '#   --colormap COLORMAP  colormap; range: 1-21; default: 3' >> ~/starter.sh.ptc.examples
#echo '#   --crosshairs         show crosshairs; no argument' >> ~/starter.sh.ptc.examples
#echo '#   --temps              show temperatures; no argument' >> ~/starter.sh.ptc.examples
#echo '#   --blur BLUR          blur radius; default: 0' >> ~/starter.sh.ptc.examples
#echo '#   --contrast CONTRAST  contrast; default: 1.0' >> ~/starter.sh.ptc.examples

# starter.sh.infiray.examples

#echo >> ~/starter.sh.infiray.examples 
#echo '# ptc script - InfiRay, etc. - options see ~/starter.sh.ptc.examples' >> ~/starter.sh.infiray.examples 
#echo >> ~/starter.sh.infiray.examples
#echo '# a few see start up options examples below' >> ~/starter.sh.infiray.examples
#echo >> ~/starter.sh.infiray.examples 
#echo "# python /home/`whoami`/testing/ptc-patched-c22-013.py --fullscreen # start in fullscreen" >> ~/starter.sh.infiray.examples
#echo >> ~/starter.sh.infiray.examples 
#echo "# python /home/`whoami`/testing/ptc-patched-c22-013.py --colormap 4 --fullscreen # start with color map 4 in fullscreen mode" >> ~/starter.sh.infiray.examples
#echo >> ~/starter.sh.infiray.examples 
#echo "# python /home/`whoami`/testing/ptc-patched-c22-013.py --crosshairs # start with crosshairs" >> ~/starter.sh.infiray.examples
#echo >> ~/starter.sh.infiray.examples 
#echo "# python /home/`whoami`/testing/ptc-patched-c22-013.py --blur 2 --contrast 1.2 # start with blur level 2 and contrast 1.2" >> ~/starter.sh.infiray.examples
#echo >> ~/starter.sh.infiray.examples 

# starter.sh (executed at desktop start up)

#echo >> ~/starter.sh
#echo >> ~/starter.sh
#echo '# ptc script - InfiRay, etc. (testing) - options see ~/starter.sh.ptc.examples' >> ~/starter.sh
#echo >> ~/starter.sh
#echo "# python /home/`whoami`/testing/ptc-patched-c22-013.py --fullscreen --colormap 20 --contrast 1.1 --blur 4 & # 256x192; options see ~/starter.sh.ptc.examples" >> ~/starter.sh
#echo >> ~/starter.sh

# move, center window in windowed mode (no fullscreen, no decor)

#echo >> ~/starter.sh
#echo '# method without grey bars in windowed mode below (no fullscreen):' >> ~/starter.sh
#echo >> ~/starter.sh
#echo "# python /home/`whoami`/testing/ptc-patched-c22-013.py --colormap 20 --contrast 1.1 --blur 4 &" >> ~/starter.sh
#echo '# while [[ $(xdotool search --name ThermalWindow) == "" ]]; do sleep 0.3; done;' >> ~/starter.sh
#echo '# xdotool search --name "ThermalWindow" windowactivate --sync %1 windowmove -- -8 -2 windowactivate $(xdotool getactivewindow)' >> ~/starter.sh
#echo '# sleep 3; xdotool search --name "ThermalWindow" windowactivate --sync %1 windowmove -- -8 -2 windowactivate $(xdotool getactivewindow)' >> ~/starter.sh

# serial Raspi CRSF daemon (Betaflight-, INAV- Ardupilot-connection)

#echo >> ~/starter.sh
#echo >> ~/starter.sh
#echo '# serial Raspi CRSF daemon; Raspi < -> flight controller (Betaflight, INAV, Ardupilot)' >> ~/starter.sh
#echo >> ~/starter.sh
#echo "# /home/`whoami`/testing/serial_fc_crsf_daemon &>/dev/null &" >> ~/starter.sh
#echo >> ~/starter.sh

echo 
echo "ptc script stuff -> ~/testing"

exit 0


